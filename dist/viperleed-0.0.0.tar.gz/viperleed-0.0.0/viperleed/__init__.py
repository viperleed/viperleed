"""
=================
    ViPErLEED
=================
"""

__version__ = '0.10.0'

GLOBALS = {
    'USE_GUI': None,
    'version': __version__,
    }

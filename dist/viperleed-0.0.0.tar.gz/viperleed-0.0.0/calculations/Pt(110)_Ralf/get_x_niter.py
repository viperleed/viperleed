
from pathlib import Path
import re
import warnings

from matplotlib import pyplot as plt

RE_ENERGY = re.compile(r"That's[\s]*(?P<energy>[.\d]+)[\s]*eV in the vacuum.")


def get_x_niter(fpath):
    """Read log file at fpath, store a csv with E, NITER, X."""
    fpath = Path(fpath).resolve()


    if not fpath.exists():
        raise FileNotFoundError("{} does not exist.".format(fpath))

    logs = fpath.glob('**/refcalc*.log')
    logs = [f for f in logs
            if (('compile' not in f.stem) and ('workhist' not in str(f)))]

    if not logs:
        raise FileNotFoundError("No refcalc log files found in "
                                "{} and subdirectories.".format(fpath))
    errors = []
    for refcalc_log in logs:
        data = {'energy': [],
                'x': [],
                'n_iter': []}
        no_convergence_egy = []

        # Read blocks, looking for an energy entry.
        # The line reads "That's    xxx.xxx      eV in the vacuum."
        x = 0
        egy = 0
        with open(refcalc_log, 'r') as log_file:
            for line in log_file:
                line = line.strip()
                e_line = RE_ENERGY.match(line)
                if e_line:
                    # Line is an energy
                    egy = float(e_line.group('energy'))
                    data['energy'].append(egy)
                    continue
                # See if line is an "X = "
                if line.startswith('X ='):
                    x = float(line.split('=')[1])
                    # Wait to store it till we get a 'iter' line
                    continue
                if line.endswith('ITER IN SUBREF'):
                    # x is the last x value:
                    data['x'].append(x)
                    data['n_iter'].append(int(line.split('ITER')[0]))
                # Another option: no convergence.
                # Line reads "NO CONV IN SUBREF AFTER xx  ITER, X = ..."
                if line.startswith('NO CONV IN SUBREF AFTER'):
                    # take X from the line, but also set some warning
                    x = float(line.split('=')[1])
                    data['x'].append(x)
                    n_iter = line.split('AFTER')[1].split('ITER')[0]
                    data['n_iter'].append(int(n_iter))
                    no_convergence_egy.append(egy)
        n_energies = len(data['energy'])
        if any(len(d) != n_energies for d in data.values()):
            errors.append(
                "Inconsistent number of energies ({})".format(n_energies)
                + ", X ({}) and n_iter ({}) ".format(len(data['x']),
                                                     len(data['n_iter']))
                + "in file {}".format(refcalc_log)
                )
            continue
        if not n_energies:
            errors.append("No energies found in {}".format(refcalc_log))
            continue
        if no_convergence_egy:
            warnings.warn(
                "Bulk doubling did not converge at the following energies "
                "for {}:\n{}".format(refcalc_log, no_convergence_egy)
                )
        # Sort by increasing energy:
        data = sorted(tuple(v) for v in zip(*data.values()))
        # Save to csv
        csv_name = refcalc_log.with_suffix('.csv')
        with open(csv_name, 'w') as csv_file:
            csv_file.write("Energy, X, NITER\n")
            for e, x, n in data:
                csv_file.write("{}, {}, {}\n".format(e, x, n))
        
        # plot stuff
        energies, xs, _ = zip(*data)
        fig = plt.figure()
        plt.plot(energies, xs)
        plt.yscale('log')
        plt.xlabel('Energy (eV)')
        plt.ylabel('Norm of bulk reflectivity (a.u.)')
        plt.savefig(csv_name.with_suffix('.pdf'))
    
    if errors:
        raise RuntimeError('\n'.join(errors))

if __name__ == '__main__':
    fpath = input("Enter path: ")
    get_x_niter(fpath)
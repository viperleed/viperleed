__version__ = '0.2.5'

from .FortranRecordReader import FortranRecordReader
from .FortranRecordWriter import FortranRecordWriter
from . import config

class InvalidFormat(Exception):
    pass

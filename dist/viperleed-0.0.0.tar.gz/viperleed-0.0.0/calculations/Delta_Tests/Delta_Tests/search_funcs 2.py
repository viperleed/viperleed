import sys
import numpy as np
import fortranformat as ff
import matplotlib.pyplot as plt
import scipy
import os
from numba import jit, njit

vpr_path = "../../../.."

if os.path.abspath(vpr_path) not in sys.path:
    sys.path.append(os.path.abspath(vpr_path))

from viperleed.tleedmlib.files.delta_intensities import *
from viperleed.tleedmlib.files.new_search import *
from viperleed.tleedmlib.files.parameters import readPARAMETERS, interpretPARAMETERS

from viperleed.tleedmlib.wrapped.rfactor import r_factor_new as rf
from viperleed.tleedmlib.wrapped.error_codes import error_codes

import pickle

import scipy.optimize


def get_beams_from_steps(delta_steps, buffer_beams, buffer):
"""This library takes implements on-the-fly calculation of delta-
amplitudes from Tensors produced by TensErLEED.
"""
    
import numpy as np

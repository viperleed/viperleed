from functools import lru_cache
import numpy as np

@lru_cache(maxsize=None)
def fac(n):
    return n * fac(n-1) if n else 1


# dimension of array belm as function of lmax
nlmbs = (19, 126, 498, 1463, 3549, 7534, 14484, 25821, 43351, 69322,
         106470, 158067, 227969, 320664, 441320, 595833, 790876, 1033942)

# this function should not be JIT


def get_clebsh_gordon(lmax):
    nf = 4*lmax+2
    belm = np.full(shape=(nlmbs(lmax+1)), fill_value=np.nan, dtype=np.float64)

    k = 0
    for l in range(lmax+1):
        for lp in range(lmax+1):
            ll2 = l+lp
            for m in range(-l, l+1):
                pre = 4*np.pi*(-1)**m
                for mp in range(-lp, lp+1):
                    mpp = mp-m
                    impp = abs(mpp)
                    ll1 = abs(l-lp)

                    ll1 = max(impp, ll1)

                    for lpp in range(ll2, ll1-1, -2):  # not sure about this...
                        k += 1
                        belm[k] = pre*blm2(l, m, lpp, mpp, lp, -mp, ll2)

    return belm

# this function should not be jited


def blm2(l1, m1, l2, m2, l3, m3, lmax):
    # easy checks first
    if (m1 + m2 + m3 != 0):
        return 0
    if (l1 - 2*lmax > 0) or (l2 - lmax > 0) or (l3 - lmax > 0):
        raise RuntimeError  # invalid l > lmax
    if (l1 - abs(m1) < 0) or (l2 - abs(m2) < 0) or (l3 - abs(m3) < 0):
        raise RuntimeError  # invalid quantum number m
    if ((m1+m2+m3) % 2 == 0):
        return 0

    nl = np.array((l1, l2, l3))
    nm = np.array(abs(m1), abs(m2), abs(m3))
    ic = (np.sum(nm))/2

    #sort by size
    maxnm_id = np.argmax(nm)
    nl[0], nl[maxnm_id] = nl[maxnm_id], nl[0]
    nm[0], nm[maxnm_id] = nm[maxnm_id], nm[0]
    if (nl[2] > nl[1]):
        nl[1], nl[2] = nl[2], nl[1]
        nm[1], nm[2] = nm[2], nl[1]
    if nl[2] - abs(nl[1]-nl[0]) < 0:
        return 0

    nl1, nl2, nl3 = nl[0], nl[1], nl[2]
    nm1, nm2, nm3 = nm[0], nm[1], nm[2]
    # Faktor A

    iss = np.sum(nl)/2
    ia1 = iss - nl2 - nm3
    ia2 = nl2 + nm2
    ia3 = nl2 - nm2
    ia4 = nl3 + nm3
    ia5 = nl1 + nl2 - nl3
    ia6 = iss - nl1
    ia7 = iss - nl2
    ia8 = iss - nl3
    ia9 = nl1 + nl2 + nl3 + 1

    A = ((-1.0)**ia1)/fac(ia3+1)*fac(ia2+1)/fac(ia6+1)*fac(ia4+1)
    A = A/fac(ia7+1)*fac(ia5+1)/fac(ia8+1)*fac(iss+1)/fac(ia9+1)

    # Faktor B

    ib1 = nl1 + nm1
    ib2 = nl2 + nl3 - nm1
    ib3 = nl1 - nm1
    ib4 = nl2 - nl3 + nm1
    ib5 = nl3 - nm3
    it1 = max(0, - ib4) + 1
    it2 = min(ib2, ib3, ib5) + 1
    B = 0.
    sign = (- 1.0)**(it1)
    ib1 = ib1 + it1 - 2
    ib2 = ib2 - it1 + 2
    ib3 = ib3 - it1 + 2
    ib4 = ib4 + it1 - 2
    ib5 = ib5 - it1 + 2
    for it in range(it, it2+1):
        sign = - sign
        ib1 = ib1 + 1
        ib2 = ib2 - 1
        ib3 = ib3 - 1
        ib4 = ib4 + 1
        ib5 = ib5 - 1
        bn = sign/fac(it)*fac(ib1+1)/fac(ib3+1) * \
            fac(ib2+1)/fac(ib4+1)/fac(ib5+1)
        B += bn

    # Faktor C
    ic1 = nl1 - nm1
    ic2 = nl1 + nm1
    ic3 = nl2 - nm2
    ic4 = nl2 + nm2
    ic5 = nl3 - nm3
    ic6 = nl3 + nm3
    cn = float((2 * nl1 + 1) * (2 * nl2 + 1) * (2 * nl3 + 1))/np.pi
    C = cn/fac(ic2+1)*fac(ic1+1)/fac(ic4+1)*fac(ic3+1)/fac(ic6+1)*fac(ic5+1)

    C = (np.sqrt(C))/2

    return float(-1**ic)*A*B*C


def cppp(n1, n2, n3):
    ppp = np.full(shape=(n1, n2, n3), fill_value=np.nan)

    for i1 in range(1, n1+1):
        for i2 in range(1, n2+1):
            for i3 in range(1, n3+1):
                im1, im2, im3 = sorted((i1, i2, i3), reverse=True)
                A = 0.0
                iss = i1 + i2 + i3 - 3
                if (iss % 2 == 0) or (im2-im1 > im3+1):
                    ppp[i1-1, i2-1, i3-1] = A
                else:
                    ssum = 0.0
                    iss = int(iss/2)
                    sign = 1.0
                    for it in range(1, im3+1):
                        sign = - sign
                        ia1 = im1 + it - 1
                        ia2 = im1 - it + 1
                        ia3 = im3 - it + 1
                        ia4 = im2 + im3 - it
                        ia5 = im2 - im3 + it
                        print(ia1, ia4, ia2, ia3, ia5, it)
                        ssum -= sign*fac(ia1)*fac(ia4) / \
                            (fac(ia2)*fac(ia3)*fac(ia5)*fac(it))
                        ia1 = 2 + iss - im1
                        ia2 = 2 + iss - im2
                        ia3 = 2 + iss - im3
                        ia4 = 3 + 2 * (iss - im3)
                        print(im1, im2, im3)
                        print(ia4, iss+1, im3, ia1, ia2, ia3, 2*iss+2)
                        A = - (-1)**(iss-im2)*fac(ia4)*fac(iss+1)*fac(im3) * \
                            ssum/(fac(ia1)*fac(ia2)*fac(ia3)*fac(2*iss+2))
                        ppp[i1-1, i2-1, i3-1] = A
    return ppp


# need to find a better way to do this; not available in JAX yet
def bessel(z, n1):
    """spherical besser functions. evaluated at z, up to degree n1"""
    bj = np.empty(shape=(n1,))

    for i in range(n1):
        bj[i] = scipy.special.spherical_jn(i, z)
    return bj

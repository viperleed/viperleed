import numpy as np

def get_coordinates_from_poscar_block(poscar_sting):
    #keep only the first 3 entries from every line
    coords = []
    lines = poscar_sting.split("\n")
    for line in lines:
        line_coords = line.split()[0:3]
        coords.extend(line_coords)
    coords = [float(n) for n in coords]
    return np.array(coords).reshape(-1, 3)

def get_formatted_poscar_block(coordinates):
    output = ""
    for row in coordinates:
        output += f"  {row[0]:<18.16f}  {row[1]:<18.16f}  {row[2]:<18.16f}\n"
    return output

def shift_z_coordinates(coordinates, z_shift):
    coordinates[:, 2] += z_shift
    coordinates[:, 2] = np.mod(coordinates[:, 2], 1)
    return coordinates
# short script to take phaseshifts generated for FeO and make ones for Fe2O3

file_in = "phas.FeO_800"

content = ""

with open(file=file_in, mode="r") as file:
    header = file.readline()
    content += header
    
    #read energy in hartree
    energy_line = file.readline()
    
    while(energy_line):
        content += energy_line

        # phaseshifts oxygen - 2 lines
        phaseshifts_O = file.readline() + file.readline()
        
        # phaseshifts Iron - 2 lines
        phaseshifts_Fe = file.readline() + file.readline()
        
        # output needs oxygen & iron 4x each
        content += 2*phaseshifts_Fe + 2*phaseshifts_O
        
        # repeat
        energy_line = file.readline()

file_out = "PHASESHIFTS"
with open(file=file_out, mode="w") as file:
    file.write(content)